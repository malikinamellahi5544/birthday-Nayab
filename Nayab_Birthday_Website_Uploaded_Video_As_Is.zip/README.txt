NAYAB BIRTHDAY WEBSITE — ALL MEDIA EMBEDDED

This build is intentionally self-contained:
- All photos are embedded directly into index.html.
- Both MP4 videos are embedded directly into index.html.
- The requested Sitaare audio segment from 2:00 to 3:55 is embedded directly into index.html.
- No images/, videos/, or song.mp3 files are required.

Open index.html directly, or upload index.html to any static hosting service.

The newly re-attached couple photo is NOT used as the hero image.
The hero uses a different uploaded couple photo.

Audio:
Click "Start Experience". This click is used to initialize audio under browser autoplay rules.
If a browser/device still has its tab/device muted, use the ♫ control after entering.

Videos:
Both videos have native browser controls and are directly clickable.
Background music pauses automatically while a video plays.


ORIENTATION + GAMES UPDATE
- Corrected the two sideways gallery images shown in the screenshots.
- Corrected the embedded videos so they display upright.
- Lightbox orientation follows the corrected gallery orientation.
- Added Love Memory Match.
- Added Pick Your Love Fortune.


FINAL ORIENTATION CORRECTION
The earlier +90° correction was reversed. The affected gallery media and video media now use -90° so they display upright rather than inverted.

VIDEO #1 FINAL FIX
The first cinema video now uses its own +90 degree correction.

FINAL LANDSCAPE VIDEO FIX
- First cinema video is rotated exactly one turn clockwise (+90 degrees).
- The player viewport stays landscape (16:9); controls are not rotated.
- Other media orientations are unchanged.

UPLOADED VIDEO REPLACEMENT
- Video #1 has been replaced with the newly uploaded MP4.
- The MP4 bytes are embedded directly in index.html.
- No CSS rotation, inversion, mirroring, or orientation transform is applied to video #1.
- It displays exactly in the orientation supplied by the uploaded file.
